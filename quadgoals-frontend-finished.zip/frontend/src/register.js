import React , { useState } from 'react';
import axios from 'axios';

// url for the server / backend
const registerUrl = 'https://7rt4z35vxi.execute-api.ap-southeast-2.amazonaws.com/prod/register';

const Register = () => {

    // variables for the userName (derbyName, Password, email and Message)
    // Note: useState preserves the value of the variable between function calls 
    // i.e. each time the Login funtion is called the value of the variables is presrved from the previous call
    const [derbyName, setDerbyName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState(null);

    const submitHandler = (event) => {
        event.preventDefault();
        if (derbyName.trim() === "" || email.trim() === "" || password.trim() === ""){
            setMessage('All fields are required');
            return;
        }

        const requestConfig = {
            headers: {
                'x-api-key': 'AgBxTRPNy45tc0mcSRIrM5P99Blj0X0K22ub6kel'
            }
        }

        const requestBody = {
            derbyName: derbyName,
            email: email,
            password: password
        }

        // use axios to send the post request and get a response
        axios.post(registerUrl, requestBody, requestConfig).then(response => {
            // if the response is successful
            setMessage('Registration Successful');
        }).catch(error => {
            // catch error messages from the response
            if(error.response.status === 401) {
                setMessage(error.response.data.message);
            } else {
                setMessage('backend server is down, try again later');
            }
        })
    }
    

    return (
        <div>
            <form onSubmit={submitHandler}>
                <label for="derbyName">Derby Name: </label> 
                <input type="text"  name="derbyName" onChange={event => setDerbyName(event.target.value)}></input>
                <br></br>
                <label for="email">Email: </label> 
                <input type="text"  name="email" onChange={event => setEmail(event.target.value)}></input>
                <br></br>
                <label for="password">Password: </label> 
                <input type="password"  name="password" onChange={event => setPassword(event.target.value)}></input>
                <br></br>
                <input type="submit" value="Register"></input>
            </form>
            {message && <p className="message">{message}</p>}
        </div>
    )
}

export default Register;