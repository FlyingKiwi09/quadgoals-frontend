import React from 'react';
import { getUser, resetUserSession } from './service/AuthService';
// used to navigate between content
import { useNavigate } from 'react-router-dom';

const ViewSkaters = () => {
    const navigate = useNavigate();

    // get skater (user) 
    const skater = getUser();
    const derbyName = skater !== 'undefined' && skater ? skater.derbyName : '';

    const logoutHandler = () => {
    resetUserSession();
    // redirect to the login page
    navigate("/login"); 
    }

    return (
        <div>
            <p>Hello {derbyName}! View your skaters here...</p>
            <input type="button" value="logout" onClick={logoutHandler}/>
        </div>
    )
}

export default ViewSkaters;