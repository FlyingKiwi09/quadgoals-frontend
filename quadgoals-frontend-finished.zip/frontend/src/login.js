import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { setUserSession } from './service/AuthService';
import axios from 'axios';

// url for the server / backend
const loginUrl = 'https://7rt4z35vxi.execute-api.ap-southeast-2.amazonaws.com/prod/login';

// props are a type of object where the value of attributes of a tag is stored
const Login = () => {
    const navigate = useNavigate();
    // variables for the userName (derbyName, Password and Message)
    // Note: useState preserves the value of the variable between function calls 
    // i.e. each time the Login funtion is called the value of the variables is presrved from the previous call
    const [derbyName, setDerbyName] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState(null);

    const submitHandler = (event) =>{
        
        event.preventDefault();
        // check user has entered name and password
        if (derbyName.trim() === '' || password.trim() === '') {
            setMessage('Enter a Derby Name and Password');
            return
        }

        // call the api
        const requestConfig = {
            headers: {
                'x-api-key': 'AgBxTRPNy45tc0mcSRIrM5P99Blj0X0K22ub6kel'
            }
        }

        const requestBody = {
            derbyName: derbyName,
            password: password
        }

        axios.post(loginUrl, requestBody, requestConfig).then((response) => {
            setUserSession(response.data.skater, response.data.token);
            // const dd=response.data.token;
            // console.log('A: '+dd);
            // console.log('B: '+JSON.stringify(response.data.skater));
            // window.sessionStorage.setItem('skater', JSON.stringify(response.data.skater));
            // window.sessionStorage.setItem('token', dd);
            // direct user to one of the user only pages (viewSkaters)
            navigate("/view-Skaters"); 
        }).catch((error) => {
            console.log(error);
            if (error.response.status === 401 || error.response.status === 403) {
                setMessage(error.response.data.message);
            } else {
                setMessage('server is down, try again later')
            }
        })
    }

    return (
        <div>
             <form onSubmit={submitHandler}>
                <label for="derbyName">Derby Name: </label> 
                <input type="text"  name="derbyName" onChange={event => setDerbyName(event.target.value)}></input>
                <br></br>
                <label for="password">Password: </label> 
                <input type="password"  name="password" onChange={event => setPassword(event.target.value)}></input>
                <br></br>
                <input type="submit" value="Login"></input>
            </form>
            {message && <p className="message">{message}</p>}
        </div>
    )
}

export default Login;