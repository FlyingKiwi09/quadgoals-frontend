import React from "react";
import { BrowserRouter, Route, Routes, NavLink } from "react-router-dom";
import Home from "./home";
import Register from "./register";
import Login from "./login";
import ViewSkaters from "./viewSkaters";
import ViewProgress from "./viewProgress";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <div className="header">
          <NavLink exact activeClassName="active" to="/">Home</NavLink>
          <NavLink activeClassName="active" to="/register">Register</NavLink>
          <NavLink activeClassName="active" to="/login">Login</NavLink>
          {/* in to="exampleName" exampleName needs to be different to the file name or it gets confused when trying to navigate  */}
          <NavLink activeClassName="active" to="/view-Skaters">View Skaters</NavLink> 
          <NavLink activeClassName="active" to="/viewProgress">Track Progress</NavLink>
        </div>
        <div className="content">
          <Routes>
            <Route exact path="/" element={ <Home/> }/>
            <Route path="/register" element={ <Register/> }/>
            <Route path="/login" element={ <Login/> }/>
            <Route path="/view-Skaters" element={ <ViewSkaters/> }/>
            <Route path="/viewProgress" element={ <ViewProgress/> }/>
          </Routes>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
