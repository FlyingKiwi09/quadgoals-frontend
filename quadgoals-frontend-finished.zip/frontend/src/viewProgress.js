import React from 'react';

const ViewProgress = () => {
    return (
        <div>
            View Staker Progress Here
        </div>
    )
}

export default ViewProgress;