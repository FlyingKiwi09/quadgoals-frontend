import React from 'react';

const Home = () => {
    return (
        <div>
            Welcome to Quad Goals
        </div>
    )
}

export default Home;