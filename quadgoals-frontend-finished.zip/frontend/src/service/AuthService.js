

module.exports = {
    getUser: function(){
        const skater = window.sessionStorage.getItem('skater');
        if (skater === 'undefined' || !skater){
            return null;
        } else {
            return JSON.parse(skater);
        }
    },

    getToken: function() {
        return window.sessionStorage.getItem('token');
    },

    setUserSession: function(skater, token) {
        window.sessionStorage.setItem('skater', JSON.stringify(skater));
        window.sessionStorage.setItem('token', token);
    },

    resetUserSession: function() {
        window.sessionStorage.removeItem('skater');
        window.sessionStorage.removeItem('token');
    }
}